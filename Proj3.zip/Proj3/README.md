# CSCE548-Project 3

This is the code for project 3.   

# Pre-steps before running the tasks 
 1. Make sure the Android VM is powered on  
 2. Type `netcfg` in the Android terminal app to determine the ip address of Android VM
 3. Insert the ip address of the Android VM into task 5 of the Makefile.  
 4. Remove the Repackaging Lab app from the device if it exists
 5. Insert a few phone contacts
 

# How to run all tasks at once
 1. In the `/Proj3` directory, run `make clean` to remove old files
 2. Type `make` to execute all five tasks

# How to run each task individually
 1. In the `/Proj3` directory, run `make clean` to remove old files
 2. Type `make task[task number]`, in which task number is the task you want to execute


# Contributions
All members participate in the project and verify each other works.  
Nathaniel, Theodore, and Philip work on Task 1 thru 4.  
Ming works on Task 5 and answers the lab questions.  
